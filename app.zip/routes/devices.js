const {Router} = require('express')
const DeviceModel = require('../models/Device')
const router = Router()




router.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'client', 'index.html'))
})

router.get('/api/devices', (req, res) => {
    res.status(200).json(DEVICES)
})

router.post('/api/devices', (req, res) => {
    const device = {...req.body, id: Date.now(), addingDate: (new Date()).toString()}
    DEVICES.push(device)
    res.status(201).json(device)
})

export default router