const {Schema, model} = require('mongoose')
const schema = new Schema({
    type: {
        type: String,
        required: true
    },
    owner: {
        type: String,
        required: true
    },
    mac: {
        type: String,
        required: true
    },
    allowed: {
        type: Boolean,
        default: false
    },
    comment: {
        type: String
    },
    addingDate: {
        type: Date
    }
})

export default model('Device', schema)


