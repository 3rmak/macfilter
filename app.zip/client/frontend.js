import Vue from 'https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.esm.browser.js'

const request = async (url, method="GET", data=null) => {
    try {
        const headers = {}
        let body
        if(data){
            headers['Content-Type'] = 'application/json'
            body = JSON.stringify(data)
        }

        const response = await fetch(url, {
            method,
            headers,
            body
        })

        return await response.json()
    } catch (e){
        console.warn('Error: ', e.message)
    }

}

new Vue({
    el: '#app',
    data() {
        return {
            form: {
                id: '',
                type: '',
                owner: '',
                mac: '',
                allowed: 'false',
                comment: '',
                addingDate: Date.now
            },
            devices: []
        }
    },
    methods: {
        async createDevice(){
            const {...device} = this.form
            await request('/api/devices', "POST", device)
            this.devices = await request('/api/devices')
            // this.devices.push({...device, id: Date.now(), addingDate: 'Был добавлен: '+(new Date()).toString()} )
            //
            // this.form.owner = this.form.mac = this.form.comment = ''
        },
        allowDevice(id){
            const device = this.devices.find(cur => cur.id === id )
            device.allowed = true
        },
        disallowDevice(id){
            const device = this.devices.find(cur => cur.id === id )
            device.allowed = false
        },
        logger() {
            console.log(this.devices)
        }
    },
    async mounted() {
        this.devices = await request('/api/devices')
    }
})


