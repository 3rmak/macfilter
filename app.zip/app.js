const express = require('express')
const {v4} = require('uuid')
const mongoose = require('mongoose')
const path = require('path')
const deviceRoutes = require('routes/devices')
const app = express()

const DEVICES = [{id: v4(),
    type: 'Смартфон',
    owner: 'Горбась Иван',
    mac: '05:05:04:04:06:06',
    allowed: false,
    comment: "Личный смартфон Redmi S2",
    addingDate: 'Был добавлен Thu Jun 10 2021 18:35:35 GMT+0300 (Восточная Европа, летнее время)' }]

app.use(express.json())
app.use(deviceRoutes)


app.use(express.static(path.resolve(__dirname, 'client')))

app.listen(3000, ()=>{
    console.log('Server has been started ')
})
